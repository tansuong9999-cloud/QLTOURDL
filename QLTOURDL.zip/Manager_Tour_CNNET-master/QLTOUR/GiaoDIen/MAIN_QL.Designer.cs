﻿namespace QLTOUR.GiaoDIen
{
    partial class MAIN_QL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MAIN_QL));
            this.btn_DatTour = new System.Windows.Forms.Button();
            this.btn_QLKH = new System.Windows.Forms.Button();
            this.btn_QLNV = new System.Windows.Forms.Button();
            this.btn_thongke = new System.Windows.Forms.Button();
            this.btn_QLTour = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnBill = new System.Windows.Forms.Button();
            this.panelFloating = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pbHomePage = new System.Windows.Forms.PictureBox();
            this.labelShowDesktop = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.labelTenNV = new System.Windows.Forms.Label();
            this.lbHi = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panelShowDesktop = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHomePage)).BeginInit();
            this.panel3.SuspendLayout();
            this.panelShowDesktop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_DatTour
            // 
            this.btn_DatTour.BackColor = System.Drawing.Color.Transparent;
            this.btn_DatTour.FlatAppearance.BorderSize = 0;
            this.btn_DatTour.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DatTour.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DatTour.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_DatTour.Image = ((System.Drawing.Image)(resources.GetObject("btn_DatTour.Image")));
            this.btn_DatTour.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_DatTour.Location = new System.Drawing.Point(0, 122);
            this.btn_DatTour.Name = "btn_DatTour";
            this.btn_DatTour.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btn_DatTour.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_DatTour.Size = new System.Drawing.Size(292, 61);
            this.btn_DatTour.TabIndex = 0;
            this.btn_DatTour.Text = "Đặt Vé";
            this.btn_DatTour.UseVisualStyleBackColor = false;
            this.btn_DatTour.Click += new System.EventHandler(this.btn_QLTour_Click);
            // 
            // btn_QLKH
            // 
            this.btn_QLKH.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLKH.FlatAppearance.BorderSize = 0;
            this.btn_QLKH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_QLKH.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_QLKH.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_QLKH.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLKH.Image")));
            this.btn_QLKH.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_QLKH.Location = new System.Drawing.Point(2, 189);
            this.btn_QLKH.Name = "btn_QLKH";
            this.btn_QLKH.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btn_QLKH.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_QLKH.Size = new System.Drawing.Size(289, 61);
            this.btn_QLKH.TabIndex = 1;
            this.btn_QLKH.Text = "Khách Hàng";
            this.btn_QLKH.UseVisualStyleBackColor = false;
            this.btn_QLKH.Click += new System.EventHandler(this.btn_QLKH_Click);
            // 
            // btn_QLNV
            // 
            this.btn_QLNV.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLNV.Enabled = false;
            this.btn_QLNV.FlatAppearance.BorderSize = 0;
            this.btn_QLNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_QLNV.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_QLNV.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_QLNV.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLNV.Image")));
            this.btn_QLNV.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_QLNV.Location = new System.Drawing.Point(0, 385);
            this.btn_QLNV.Name = "btn_QLNV";
            this.btn_QLNV.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btn_QLNV.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_QLNV.Size = new System.Drawing.Size(292, 61);
            this.btn_QLNV.TabIndex = 3;
            this.btn_QLNV.Text = "Quản Lý Nhân Viên";
            this.btn_QLNV.UseVisualStyleBackColor = false;
            this.btn_QLNV.Click += new System.EventHandler(this.btn_QLNV_Click);
            // 
            // btn_thongke
            // 
            this.btn_thongke.BackColor = System.Drawing.Color.Transparent;
            this.btn_thongke.Enabled = false;
            this.btn_thongke.FlatAppearance.BorderSize = 0;
            this.btn_thongke.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_thongke.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_thongke.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_thongke.Image = ((System.Drawing.Image)(resources.GetObject("btn_thongke.Image")));
            this.btn_thongke.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_thongke.Location = new System.Drawing.Point(0, 452);
            this.btn_thongke.Name = "btn_thongke";
            this.btn_thongke.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btn_thongke.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_thongke.Size = new System.Drawing.Size(292, 61);
            this.btn_thongke.TabIndex = 4;
            this.btn_thongke.Text = "Thống Kê";
            this.btn_thongke.UseVisualStyleBackColor = false;
            this.btn_thongke.Click += new System.EventHandler(this.btn_QLDT_Click);
            // 
            // btn_QLTour
            // 
            this.btn_QLTour.BackColor = System.Drawing.Color.Transparent;
            this.btn_QLTour.FlatAppearance.BorderSize = 0;
            this.btn_QLTour.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_QLTour.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_QLTour.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_QLTour.Image = ((System.Drawing.Image)(resources.GetObject("btn_QLTour.Image")));
            this.btn_QLTour.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_QLTour.Location = new System.Drawing.Point(0, 256);
            this.btn_QLTour.Name = "btn_QLTour";
            this.btn_QLTour.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btn_QLTour.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_QLTour.Size = new System.Drawing.Size(292, 61);
            this.btn_QLTour.TabIndex = 5;
            this.btn_QLTour.Text = "Quản Lý Tour";
            this.btn_QLTour.UseVisualStyleBackColor = false;
            this.btn_QLTour.Click += new System.EventHandler(this.btn_QLTour_Click_1);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(71)))), ((int)(((byte)(99)))));
            this.panel1.Controls.Add(this.btn_QLNV);
            this.panel1.Controls.Add(this.btnBill);
            this.panel1.Controls.Add(this.btn_DatTour);
            this.panel1.Controls.Add(this.panelFloating);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.btn_LogOut);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.btn_thongke);
            this.panel1.Controls.Add(this.btn_QLTour);
            this.panel1.Controls.Add(this.btn_QLKH);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.panel1.Size = new System.Drawing.Size(298, 861);
            this.panel1.TabIndex = 6;
            // 
            // btnBill
            // 
            this.btnBill.BackColor = System.Drawing.Color.Transparent;
            this.btnBill.FlatAppearance.BorderSize = 0;
            this.btnBill.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBill.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBill.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBill.Image = ((System.Drawing.Image)(resources.GetObject("btnBill.Image")));
            this.btnBill.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBill.Location = new System.Drawing.Point(0, 323);
            this.btnBill.Name = "btnBill";
            this.btnBill.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnBill.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnBill.Size = new System.Drawing.Size(292, 61);
            this.btnBill.TabIndex = 9;
            this.btnBill.Text = "Hóa Đơn";
            this.btnBill.UseVisualStyleBackColor = false;
            this.btnBill.Click += new System.EventHandler(this.btnBill_Click);
            // 
            // panelFloating
            // 
            this.panelFloating.BackColor = System.Drawing.Color.White;
            this.panelFloating.Location = new System.Drawing.Point(3, 117);
            this.panelFloating.Name = "panelFloating";
            this.panelFloating.Size = new System.Drawing.Size(5, 61);
            this.panelFloating.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Roboto Thin", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(61, 777);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Made by Group 2";
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.BackColor = System.Drawing.Color.Transparent;
            this.btn_LogOut.FlatAppearance.BorderSize = 0;
            this.btn_LogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LogOut.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LogOut.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_LogOut.Image = ((System.Drawing.Image)(resources.GetObject("btn_LogOut.Image")));
            this.btn_LogOut.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_LogOut.Location = new System.Drawing.Point(0, 519);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btn_LogOut.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btn_LogOut.Size = new System.Drawing.Size(292, 61);
            this.btn_LogOut.TabIndex = 8;
            this.btn_LogOut.Text = "Đăng Xuất";
            this.btn_LogOut.UseVisualStyleBackColor = false;
            this.btn_LogOut.Click += new System.EventHandler(this.btn_LogOut_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(71)))), ((int)(((byte)(99)))));
            this.panel2.Controls.Add(this.pbHomePage);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(298, 116);
            this.panel2.TabIndex = 7;
            // 
            // pbHomePage
            // 
            this.pbHomePage.Image = ((System.Drawing.Image)(resources.GetObject("pbHomePage.Image")));
            this.pbHomePage.Location = new System.Drawing.Point(3, 3);
            this.pbHomePage.Name = "pbHomePage";
            this.pbHomePage.Size = new System.Drawing.Size(289, 110);
            this.pbHomePage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbHomePage.TabIndex = 1;
            this.pbHomePage.TabStop = false;
            this.pbHomePage.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // labelShowDesktop
            // 
            this.labelShowDesktop.AutoSize = true;
            this.labelShowDesktop.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelShowDesktop.Location = new System.Drawing.Point(288, 32);
            this.labelShowDesktop.Name = "labelShowDesktop";
            this.labelShowDesktop.Size = new System.Drawing.Size(433, 42);
            this.labelShowDesktop.TabIndex = 2;
            this.labelShowDesktop.Text = "Quản Lý TOUR Du Lịch";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(71)))), ((int)(((byte)(99)))));
            this.panel3.Controls.Add(this.labelTenNV);
            this.panel3.Controls.Add(this.lbHi);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.labelShowDesktop);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(298, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1586, 116);
            this.panel3.TabIndex = 7;
            // 
            // labelTenNV
            // 
            this.labelTenNV.AutoSize = true;
            this.labelTenNV.Font = new System.Drawing.Font("Roboto Light", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTenNV.Location = new System.Drawing.Point(1194, 69);
            this.labelTenNV.Name = "labelTenNV";
            this.labelTenNV.Size = new System.Drawing.Size(0, 33);
            this.labelTenNV.TabIndex = 6;
            // 
            // lbHi
            // 
            this.lbHi.AutoSize = true;
            this.lbHi.Font = new System.Drawing.Font("Roboto Light", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHi.Location = new System.Drawing.Point(1020, 69);
            this.lbHi.Name = "lbHi";
            this.lbHi.Size = new System.Drawing.Size(139, 33);
            this.lbHi.TabIndex = 5;
            this.lbHi.Text = "Nhân viên:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Monotype Corsiva", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(86, -12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(480, 45);
            this.label2.TabIndex = 4;
            this.label2.Text = "_______________________";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(288, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(480, 45);
            this.label1.TabIndex = 3;
            this.label1.Text = "_______________________";
            // 
            // panelShowDesktop
            // 
            this.panelShowDesktop.BackColor = System.Drawing.SystemColors.Control;
            this.panelShowDesktop.BackgroundImage = global::QLTOUR.Properties.Resources.halong1;
            this.panelShowDesktop.Controls.Add(this.pictureBox1);
            this.panelShowDesktop.ForeColor = System.Drawing.Color.Black;
            this.panelShowDesktop.Location = new System.Drawing.Point(298, 116);
            this.panelShowDesktop.Name = "panelShowDesktop";
            this.panelShowDesktop.Size = new System.Drawing.Size(1586, 745);
            this.panelShowDesktop.TabIndex = 8;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1003, 43);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(538, 206);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // MAIN_QL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1884, 861);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panelShowDesktop);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "MAIN_QL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MAIN_QL";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MAIN_QL_FormClosing);
            this.Load += new System.EventHandler(this.MAIN_QL_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbHomePage)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panelShowDesktop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_DatTour;
        private System.Windows.Forms.Button btn_QLKH;
        private System.Windows.Forms.Button btn_QLNV;
        private System.Windows.Forms.Button btn_thongke;
        private System.Windows.Forms.Button btn_QLTour;
          private System.Windows.Forms.Panel panel1;
          private System.Windows.Forms.Panel panel2;
          private System.Windows.Forms.PictureBox pbHomePage;
          private System.Windows.Forms.Label labelShowDesktop;
          private System.Windows.Forms.Panel panel3;
          private System.Windows.Forms.Panel panelShowDesktop;
          private System.Windows.Forms.Label label2;
          private System.Windows.Forms.Label label1;
          private System.Windows.Forms.Button btn_LogOut;
          private System.Windows.Forms.Label label3;
          private System.Windows.Forms.Panel panelFloating;
          private System.Windows.Forms.Button btnBill;
          private System.Windows.Forms.Label labelTenNV;
          private System.Windows.Forms.Label lbHi;
          private System.Windows.Forms.PictureBox pictureBox1;
     }
}