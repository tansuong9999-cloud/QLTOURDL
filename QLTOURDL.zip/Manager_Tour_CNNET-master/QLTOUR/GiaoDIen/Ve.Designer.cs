﻿namespace QLTOUR.GiaoDIen
{
    partial class Ve
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lb_thoigian = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lb_valueslve = new System.Windows.Forms.Label();
            this.lb_slve = new System.Windows.Forms.Label();
            this.lb_phuongtien = new System.Windows.Forms.Label();
            this.lb_xp = new System.Windows.Forms.Label();
            this.lb_valuexp = new System.Windows.Forms.Label();
            this.lb_valuephuongtien = new System.Windows.Forms.Label();
            this.lb_matour = new System.Windows.Forms.Label();
            this.lb_tentour = new System.Windows.Forms.Label();
            this.lb_tgketthuc = new System.Windows.Forms.Label();
            this.lb_tgbatdau = new System.Windows.Forms.Label();
            this.lb_giatour = new System.Windows.Forms.Label();
            this.txt_sdt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_kiemtraKH = new System.Windows.Forms.Button();
            this.gb_thongtinKH = new System.Windows.Forms.GroupBox();
            this.lb_gioitinh = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lb_email = new System.Windows.Forms.Label();
            this.lb_sdt = new System.Windows.Forms.Label();
            this.lb_hoten = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_slgve = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lb_thanhtien = new System.Windows.Forms.Label();
            this.btn_thanhtoan = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.gb_thongtinKH.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.lb_thoigian);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.lb_valueslve);
            this.groupBox1.Controls.Add(this.lb_slve);
            this.groupBox1.Controls.Add(this.lb_phuongtien);
            this.groupBox1.Controls.Add(this.lb_xp);
            this.groupBox1.Controls.Add(this.lb_valuexp);
            this.groupBox1.Controls.Add(this.lb_valuephuongtien);
            this.groupBox1.Controls.Add(this.lb_matour);
            this.groupBox1.Controls.Add(this.lb_tentour);
            this.groupBox1.Location = new System.Drawing.Point(273, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(557, 154);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // lb_thoigian
            // 
            this.lb_thoigian.AutoSize = true;
            this.lb_thoigian.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.lb_thoigian.Location = new System.Drawing.Point(35, 97);
            this.lb_thoigian.Name = "lb_thoigian";
            this.lb_thoigian.Size = new System.Drawing.Size(30, 19);
            this.lb_thoigian.TabIndex = 27;
            this.lb_thoigian.Text = "TG";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.label6.Location = new System.Drawing.Point(71, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 19);
            this.label6.TabIndex = 26;
            this.label6.Text = "Ngày";
            // 
            // lb_valueslve
            // 
            this.lb_valueslve.AutoSize = true;
            this.lb_valueslve.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.lb_valueslve.Location = new System.Drawing.Point(349, 32);
            this.lb_valueslve.Name = "lb_valueslve";
            this.lb_valueslve.Size = new System.Drawing.Size(50, 19);
            this.lb_valueslve.TabIndex = 25;
            this.lb_valueslve.Text = "SL vé ";
            // 
            // lb_slve
            // 
            this.lb_slve.AutoSize = true;
            this.lb_slve.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.lb_slve.Location = new System.Drawing.Point(215, 32);
            this.lb_slve.Name = "lb_slve";
            this.lb_slve.Size = new System.Drawing.Size(100, 19);
            this.lb_slve.TabIndex = 24;
            this.lb_slve.Text = "SL vé còn lại:";
            // 
            // lb_phuongtien
            // 
            this.lb_phuongtien.AutoSize = true;
            this.lb_phuongtien.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.lb_phuongtien.Location = new System.Drawing.Point(215, 97);
            this.lb_phuongtien.Name = "lb_phuongtien";
            this.lb_phuongtien.Size = new System.Drawing.Size(97, 19);
            this.lb_phuongtien.TabIndex = 23;
            this.lb_phuongtien.Text = "Phương tiện:";
            // 
            // lb_xp
            // 
            this.lb_xp.AutoSize = true;
            this.lb_xp.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.lb_xp.Location = new System.Drawing.Point(215, 65);
            this.lb_xp.Name = "lb_xp";
            this.lb_xp.Size = new System.Drawing.Size(124, 19);
            this.lb_xp.TabIndex = 22;
            this.lb_xp.Text = "Điểm xuất phát: ";
            // 
            // lb_valuexp
            // 
            this.lb_valuexp.AutoSize = true;
            this.lb_valuexp.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.lb_valuexp.Location = new System.Drawing.Point(349, 65);
            this.lb_valuexp.Name = "lb_valuexp";
            this.lb_valuexp.Size = new System.Drawing.Size(78, 19);
            this.lb_valuexp.TabIndex = 21;
            this.lb_valuexp.Text = "Xuất phát";
            // 
            // lb_valuephuongtien
            // 
            this.lb_valuephuongtien.AutoSize = true;
            this.lb_valuephuongtien.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.lb_valuephuongtien.Location = new System.Drawing.Point(349, 97);
            this.lb_valuephuongtien.Name = "lb_valuephuongtien";
            this.lb_valuephuongtien.Size = new System.Drawing.Size(94, 19);
            this.lb_valuephuongtien.TabIndex = 20;
            this.lb_valuephuongtien.Text = "Phương tien";
            // 
            // lb_matour
            // 
            this.lb_matour.AutoSize = true;
            this.lb_matour.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.lb_matour.Location = new System.Drawing.Point(35, 32);
            this.lb_matour.Name = "lb_matour";
            this.lb_matour.Size = new System.Drawing.Size(64, 19);
            this.lb_matour.TabIndex = 19;
            this.lb_matour.Text = "Mã tour";
            // 
            // lb_tentour
            // 
            this.lb_tentour.AutoSize = true;
            this.lb_tentour.Font = new System.Drawing.Font("Roboto", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tentour.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lb_tentour.Location = new System.Drawing.Point(35, 65);
            this.lb_tentour.Name = "lb_tentour";
            this.lb_tentour.Size = new System.Drawing.Size(83, 20);
            this.lb_tentour.TabIndex = 15;
            this.lb_tentour.Text = "Tên TOUR";
            // 
            // lb_tgketthuc
            // 
            this.lb_tgketthuc.AutoSize = true;
            this.lb_tgketthuc.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.lb_tgketthuc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lb_tgketthuc.Location = new System.Drawing.Point(140, 130);
            this.lb_tgketthuc.Name = "lb_tgketthuc";
            this.lb_tgketthuc.Size = new System.Drawing.Size(67, 19);
            this.lb_tgketthuc.TabIndex = 28;
            this.lb_tgketthuc.Text = "Kết thúc";
            // 
            // lb_tgbatdau
            // 
            this.lb_tgbatdau.AutoSize = true;
            this.lb_tgbatdau.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.lb_tgbatdau.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lb_tgbatdau.Location = new System.Drawing.Point(140, 91);
            this.lb_tgbatdau.Name = "lb_tgbatdau";
            this.lb_tgbatdau.Size = new System.Drawing.Size(78, 19);
            this.lb_tgbatdau.TabIndex = 26;
            this.lb_tgbatdau.Text = "Xuất phát";
            // 
            // lb_giatour
            // 
            this.lb_giatour.AutoSize = true;
            this.lb_giatour.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.lb_giatour.Location = new System.Drawing.Point(140, 220);
            this.lb_giatour.Name = "lb_giatour";
            this.lb_giatour.Size = new System.Drawing.Size(76, 19);
            this.lb_giatour.TabIndex = 16;
            this.lb_giatour.Text = "value_gia";
            // 
            // txt_sdt
            // 
            this.txt_sdt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_sdt.Font = new System.Drawing.Font("Roboto Light", 17F);
            this.txt_sdt.Location = new System.Drawing.Point(31, 227);
            this.txt_sdt.Name = "txt_sdt";
            this.txt_sdt.Size = new System.Drawing.Size(269, 28);
            this.txt_sdt.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.label1.Location = new System.Drawing.Point(27, 205);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(229, 19);
            this.label1.TabIndex = 18;
            this.label1.Text = "Nhập số điện thoại khách hàng";
            // 
            // btn_kiemtraKH
            // 
            this.btn_kiemtraKH.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_kiemtraKH.FlatAppearance.BorderSize = 0;
            this.btn_kiemtraKH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_kiemtraKH.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.btn_kiemtraKH.ForeColor = System.Drawing.Color.White;
            this.btn_kiemtraKH.Location = new System.Drawing.Point(311, 227);
            this.btn_kiemtraKH.Name = "btn_kiemtraKH";
            this.btn_kiemtraKH.Size = new System.Drawing.Size(127, 28);
            this.btn_kiemtraKH.TabIndex = 19;
            this.btn_kiemtraKH.Text = "Kiểm tra";
            this.btn_kiemtraKH.UseVisualStyleBackColor = false;
            this.btn_kiemtraKH.Click += new System.EventHandler(this.btn_kiemtraKH_Click);
            // 
            // gb_thongtinKH
            // 
            this.gb_thongtinKH.Controls.Add(this.lb_gioitinh);
            this.gb_thongtinKH.Controls.Add(this.label12);
            this.gb_thongtinKH.Controls.Add(this.lb_email);
            this.gb_thongtinKH.Controls.Add(this.lb_sdt);
            this.gb_thongtinKH.Controls.Add(this.lb_hoten);
            this.gb_thongtinKH.Controls.Add(this.label2);
            this.gb_thongtinKH.Controls.Add(this.label3);
            this.gb_thongtinKH.Controls.Add(this.label4);
            this.gb_thongtinKH.Location = new System.Drawing.Point(31, 280);
            this.gb_thongtinKH.Name = "gb_thongtinKH";
            this.gb_thongtinKH.Size = new System.Drawing.Size(557, 428);
            this.gb_thongtinKH.TabIndex = 20;
            this.gb_thongtinKH.TabStop = false;
            this.gb_thongtinKH.Text = "Thông tin khách hàng";
            this.gb_thongtinKH.Visible = false;
            this.gb_thongtinKH.Enter += new System.EventHandler(this.gb_thongtinKH_Enter);
            // 
            // lb_gioitinh
            // 
            this.lb_gioitinh.AutoSize = true;
            this.lb_gioitinh.Font = new System.Drawing.Font("Roboto Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_gioitinh.Location = new System.Drawing.Point(173, 214);
            this.lb_gioitinh.Name = "lb_gioitinh";
            this.lb_gioitinh.Size = new System.Drawing.Size(109, 19);
            this.lb_gioitinh.TabIndex = 38;
            this.lb_gioitinh.Text = "Value_gioitinh";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Roboto Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Maroon;
            this.label12.Location = new System.Drawing.Point(36, 214);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(68, 19);
            this.label12.TabIndex = 37;
            this.label12.Text = "Giới tính";
            // 
            // lb_email
            // 
            this.lb_email.AutoSize = true;
            this.lb_email.Font = new System.Drawing.Font("Roboto Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_email.Location = new System.Drawing.Point(173, 167);
            this.lb_email.Name = "lb_email";
            this.lb_email.Size = new System.Drawing.Size(96, 19);
            this.lb_email.TabIndex = 36;
            this.lb_email.Text = "Value_Email";
            // 
            // lb_sdt
            // 
            this.lb_sdt.AutoSize = true;
            this.lb_sdt.Font = new System.Drawing.Font("Roboto Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_sdt.Location = new System.Drawing.Point(173, 115);
            this.lb_sdt.Name = "lb_sdt";
            this.lb_sdt.Size = new System.Drawing.Size(85, 19);
            this.lb_sdt.TabIndex = 35;
            this.lb_sdt.Text = "Value_SDT";
            // 
            // lb_hoten
            // 
            this.lb_hoten.AutoSize = true;
            this.lb_hoten.Font = new System.Drawing.Font("Roboto Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_hoten.Location = new System.Drawing.Point(173, 63);
            this.lb_hoten.Name = "lb_hoten";
            this.lb_hoten.Size = new System.Drawing.Size(77, 19);
            this.lb_hoten.TabIndex = 33;
            this.lb_hoten.Text = "Value_HT";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Roboto Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(36, 167);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 19);
            this.label2.TabIndex = 32;
            this.label2.Text = "Email";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Roboto Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Maroon;
            this.label3.Location = new System.Drawing.Point(36, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 19);
            this.label3.TabIndex = 31;
            this.label3.Text = "Số điện thoại: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Roboto Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Maroon;
            this.label4.Location = new System.Drawing.Point(36, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 19);
            this.label4.TabIndex = 30;
            this.label4.Text = "Họ Tên";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.label7.Location = new System.Drawing.Point(26, 220);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 19);
            this.label7.TabIndex = 29;
            this.label7.Text = "Giá:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Roboto Light", 16F);
            this.label8.Location = new System.Drawing.Point(153, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(132, 27);
            this.label8.TabIndex = 30;
            this.label8.Text = "Thông tin Vé";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.label9.Location = new System.Drawing.Point(26, 91);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 19);
            this.label9.TabIndex = 31;
            this.label9.Text = "Thời gian:";
            // 
            // txt_slgve
            // 
            this.txt_slgve.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_slgve.Font = new System.Drawing.Font("Roboto Light", 14F);
            this.txt_slgve.Location = new System.Drawing.Point(144, 166);
            this.txt_slgve.Name = "txt_slgve";
            this.txt_slgve.Size = new System.Drawing.Size(260, 23);
            this.txt_slgve.TabIndex = 32;
            this.txt_slgve.TextChanged += new System.EventHandler(this.txt_slgve_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.label10.Location = new System.Drawing.Point(26, 169);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 19);
            this.label10.TabIndex = 33;
            this.label10.Text = "Số lượng vé: ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.label11.Location = new System.Drawing.Point(26, 267);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 19);
            this.label11.TabIndex = 34;
            this.label11.Text = "Tổng cộng:";
            // 
            // lb_thanhtien
            // 
            this.lb_thanhtien.AutoSize = true;
            this.lb_thanhtien.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.lb_thanhtien.Location = new System.Drawing.Point(140, 267);
            this.lb_thanhtien.Name = "lb_thanhtien";
            this.lb_thanhtien.Size = new System.Drawing.Size(121, 19);
            this.lb_thanhtien.TabIndex = 35;
            this.lb_thanhtien.Text = "value_tongcong";
            this.lb_thanhtien.Visible = false;
            // 
            // btn_thanhtoan
            // 
            this.btn_thanhtoan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn_thanhtoan.FlatAppearance.BorderSize = 0;
            this.btn_thanhtoan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_thanhtoan.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.btn_thanhtoan.ForeColor = System.Drawing.Color.White;
            this.btn_thanhtoan.Location = new System.Drawing.Point(912, 37);
            this.btn_thanhtoan.Name = "btn_thanhtoan";
            this.btn_thanhtoan.Size = new System.Drawing.Size(142, 43);
            this.btn_thanhtoan.TabIndex = 36;
            this.btn_thanhtoan.Text = "Thanh Toán";
            this.btn_thanhtoan.UseVisualStyleBackColor = false;
            this.btn_thanhtoan.Click += new System.EventHandler(this.btn_thanhtoan_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Roboto Light", 12F);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(912, 95);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(142, 43);
            this.button2.TabIndex = 37;
            this.button2.Text = "Thoát";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.lb_tgbatdau);
            this.groupBox2.Controls.Add(this.lb_tgketthuc);
            this.groupBox2.Controls.Add(this.lb_thanhtien);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txt_slgve);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.lb_giatour);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Location = new System.Drawing.Point(612, 280);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(442, 428);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            // 
            // Ve
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1084, 744);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.gb_thongtinKH);
            this.Controls.Add(this.btn_thanhtoan);
            this.Controls.Add(this.btn_kiemtraKH);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_sdt);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Ve";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QLVe";
            this.Load += new System.EventHandler(this.QLVe_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gb_thongtinKH.ResumeLayout(false);
            this.gb_thongtinKH.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lb_tgketthuc;
        private System.Windows.Forms.Label lb_tgbatdau;
        private System.Windows.Forms.Label lb_valueslve;
        private System.Windows.Forms.Label lb_slve;
        private System.Windows.Forms.Label lb_phuongtien;
        private System.Windows.Forms.Label lb_xp;
        private System.Windows.Forms.Label lb_valuexp;
        private System.Windows.Forms.Label lb_valuephuongtien;
        private System.Windows.Forms.Label lb_matour;
        private System.Windows.Forms.Label lb_tentour;
        private System.Windows.Forms.Label lb_giatour;
        private System.Windows.Forms.TextBox txt_sdt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_kiemtraKH;
        private System.Windows.Forms.GroupBox gb_thongtinKH;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lb_email;
        private System.Windows.Forms.Label lb_sdt;
        private System.Windows.Forms.Label lb_hoten;
        private System.Windows.Forms.Label lb_thoigian;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_slgve;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lb_thanhtien;
        private System.Windows.Forms.Button btn_thanhtoan;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ErrorProvider errorProvider1;
          private System.Windows.Forms.GroupBox groupBox2;
          private System.Windows.Forms.Label lb_gioitinh;
          private System.Windows.Forms.Label label12;
     }
}